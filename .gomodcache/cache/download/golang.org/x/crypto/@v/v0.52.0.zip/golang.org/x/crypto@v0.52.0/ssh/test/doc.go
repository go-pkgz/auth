// Copyright 2012 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Package test contains integration tests for the
// golang.org/x/crypto/ssh package.
//
// Deprecated: this package is for internal use only.
package test
